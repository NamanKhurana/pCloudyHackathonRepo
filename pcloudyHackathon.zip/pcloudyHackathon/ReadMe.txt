
Installation
Clone the git repository in your system

Usage
Run the Java code from - HackathonTestScenarios.java - All the test scenarios are present here.

Report

After running the suite an Extent Report will be generated in the file directory with each step and screen shot mentioned


