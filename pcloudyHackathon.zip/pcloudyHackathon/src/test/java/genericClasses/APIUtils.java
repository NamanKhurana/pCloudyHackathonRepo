package genericClasses;

import io.restassured.response.Response;

public class APIUtils {

	
	
}
