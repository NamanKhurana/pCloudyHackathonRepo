package genericClasses;

public class Config {

	String pCloudy_Username = "naman.khurana@naukri.com";
	String pCloudy_ApiKey = "47s3dcg53myt935jpcrt7dw6";
	String APP_PACKAGE = "com.pcloudyhackathon";
	String APP_ACTIVITY = ".ui.login.LoginActivity";
	String pCloudy_ApplicationName= "PCloudyHackathon.apk";
	
	
	
}

